package me.antifreecam;

import com.mojang.brigadier.CommandDispatcher;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_12099;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class AntiFreecamCommand {
    private static final Set<UUID> exemptPlayers = new HashSet<>();

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
                class_2170.method_9247("antifreecam")
                        .requires(source -> source.method_75037().hasPermission(class_12099.field_63209)) // op level 2
                        .then(class_2170.method_9247("exempt")
                                .then(class_2170.method_9244("player", class_2186.method_9305())
                                        .then(class_2170.method_9247("add")
                                                .executes(ctx -> {
                                                    class_3222 player = class_2186.method_9315(ctx, "player");
                                                    exemptPlayers.add(player.method_5667());
                                                    ctx.getSource().method_9226(
                                                            () -> class_2561.method_43470(player.method_5477().getString() + " is now exempt from AntiFreecam"), true);
                                                    return 1;
                                                }))
                                        .then(class_2170.method_9247("remove")
                                                .executes(ctx -> {
                                                    class_3222 player = class_2186.method_9315(ctx, "player");
                                                    exemptPlayers.remove(player.method_5667());
                                                    ctx.getSource().method_9226(
                                                            () -> class_2561.method_43470(player.method_5477().getString() + " is no longer exempt from AntiFreecam"), true);
                                                    return 1;
                                                }))
                                        .then(class_2170.method_9247("check")
                                                .executes(ctx -> {
                                                    class_3222 player = class_2186.method_9315(ctx, "player");
                                                    boolean exempt = exemptPlayers.contains(player.method_5667());
                                                    ctx.getSource().method_9226(
                                                            () -> class_2561.method_43470(player.method_5477().getString() + " is " + (exempt ? "exempt" : "not exempt")), false);
                                                    return 1;
                                                }))
                                )
                        )
        );
    }

    public static boolean isExempt(class_3222 player) {
        return exemptPlayers.contains(player.method_5667());
    }
}