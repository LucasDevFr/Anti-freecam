package me.antifreecam;

import me.antifreecam.config.AntiFrecamConfig;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_12099;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static net.minecraft.class_2170.method_9247;

public class AntiFreecamMod implements ModInitializer {

    public static final String MOD_ID = "antifreecam";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static AntiFrecamConfig CONFIG;

    @Override
    public void onInitialize() {
        CONFIG = AntiFrecamConfig.load();
        LOGGER.info("[AntiFreecam] Loaded. Y-range: ±{} sections, Surface threshold: Y={}",
                CONFIG.sectionRadius, CONFIG.surfaceThreshold);


        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                AntiFreecamCommand.register(dispatcher));

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                    method_9247("antifreecam")
                            .requires(src -> src.method_75037().hasPermission(class_12099.field_63209))
                            .then(method_9247("reload")
                                    .executes(ctx -> {
                                        CONFIG = AntiFrecamConfig.load();
                                        ctx.getSource().method_9226(
                                                () -> class_2561.method_43470("[AntiFrecam] Config reloaded."), true);
                                        return 1;
                                    })
                            )
                            .then(method_9247("status")
                                    .executes(ctx -> {
                                        class_2168 src = ctx.getSource();
                                        src.method_9226(() -> class_2561.method_43470(
                                                "[AntiFrecam] enabled=" + CONFIG.enabled
                                                        + " | sectionRadius=" + CONFIG.sectionRadius
                                                        + " | surfaceThreshold=" + CONFIG.surfaceThreshold
                                                        + " | maskBlock=" + CONFIG.maskBlock), false);
                                        return 1;
                                    })
                            )
            );
        });
    }
}