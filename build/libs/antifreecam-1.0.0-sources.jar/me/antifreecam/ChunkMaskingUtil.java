package me.antifreecam;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2672;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

import static me.antifreecam.AntiFreecamMod.CONFIG;

public class ChunkMaskingUtil {
    private static class_2826 fake;

    public static class_2672 buildMaskedPacket(
            class_2818 chunk, class_3218 level, class_3222 player) {

        int playerY = (int) Math.floor(player.method_23318());
        playerY = Math.min(playerY, CONFIG.surfaceThreshold);

        int playerSection = Math.floorDiv(playerY - chunk.method_31607(), 16);
        int revealDownToSection = playerSection - 1;

        class_2680 mask = getMaskState();
        class_2826[] realSections = chunk.method_12006();
        class_2826[] backup = realSections.clone();

        if (CONFIG.engineMode == 1) {
            try {
                for (int i = 0; i < realSections.length; i++) {
                    if (i < revealDownToSection) {
                        if (fake == null) {
                            fake = realSections[i].method_61771();
                            for (int x = 0; x < 16; x++)
                                for (int y = 0; y < 16; y++)
                                    for (int z = 0; z < 16; z++)
                                        fake.method_12256(x, y, z, mask, false);
                        }
                        realSections[i] = fake.method_61771();
                    }
                }
                return new class_2672(chunk, level.method_22336(), null, null);
            } finally {
                System.arraycopy(backup, 0, realSections, 0, backup.length);
            }
        } else  {
            // Find the reference section to copy — the lowest visible one
            // This is the section just at the cutoff, which is typically stone/ground
            class_2826 referenceSectionToCopy = realSections[Math.max(revealDownToSection, 0)];

            try {
                for (int i = 0; i < revealDownToSection; i++) {
                    realSections[i] = referenceSectionToCopy.method_61771();
                }
                return new class_2672(chunk, level.method_22336(), null, null);
            } finally {
                System.arraycopy(backup, 0, realSections, 0, backup.length);
            }
        }

    }

    private static class_2680 getMaskState() {
        String blockId = CONFIG.maskBlock;
        Optional<class_6880.class_6883<class_2248>> optional =
                class_7923.field_41175.method_10223(class_2960.method_60654(blockId));
        if (optional.isEmpty()) {
            AntiFreecamMod.LOGGER.warn("[AntiFreecam] maskBlock '{}' not found, falling back to stone", blockId);
            return class_2246.field_10340.method_9564();
        }
        return optional.get().comp_349().method_9564();
    }

    public static boolean isEntityInMaskedSection(class_1297 entity, class_3222 player) {
        // reuse your existing player Y / surface threshold logic
        int effectiveY = Math.min((int) Math.floor(player.method_23318()), AntiFreecamMod.CONFIG.surfaceThreshold);
        int currentPlayerSection = Math.floorDiv(effectiveY, 16);
        int effectiveEntityY = Math.min((int) Math.floor(entity.method_23318()), AntiFreecamMod.CONFIG.surfaceThreshold);
        int currentEntitySection = Math.floorDiv(effectiveEntityY, 16);
        return currentEntitySection < currentPlayerSection-1;
    }
}