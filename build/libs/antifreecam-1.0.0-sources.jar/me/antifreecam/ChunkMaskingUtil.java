package me.antifreecam;

import java.util.Optional;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2672;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class ChunkMaskingUtil {
    public static class_2672 buildMaskedPacket(
            class_2818 chunk, class_3218 level, class_3222 player) {

        int playerY = (int) Math.floor(player.method_23318());
        playerY = Math.min(playerY, AntiFreecamMod.CONFIG.surfaceThreshold);

        int playerSection = Math.floorDiv(playerY - chunk.method_31607(), 16);
        int revealDownToSection = playerSection - 1;

        class_2680 mask = getMaskState();
        class_2826[] realSections = chunk.method_12006();
        class_2826[] backup = realSections.clone();
        try {
            for (int i = 0; i < realSections.length; i++) {
                if (i < revealDownToSection) {
                    class_2826 fake = realSections[i].method_61771();
                    for (int x = 0; x < 16; x++)
                        for (int y = 0; y < 16; y++)
                            for (int z = 0; z < 16; z++)
                                fake.method_12256(x, y, z, mask, false);
                    realSections[i] = fake;
                }
            }
            return new class_2672(chunk, level.method_22336(), null, null);
        } finally {
            System.arraycopy(backup, 0, realSections, 0, backup.length);
        }
    }

    private static class_2680 getMaskState() {
        String blockId = AntiFreecamMod.CONFIG.maskBlock;
        Optional<class_6880.class_6883<class_2248>> optional =
                class_7923.field_41175.method_10223(class_2960.method_60654(blockId));
        if (optional.isEmpty()) {
            AntiFreecamMod.LOGGER.warn("[AntiFreecam] maskBlock '{}' not found, falling back to stone", blockId);
            return class_2246.field_10340.method_9564();
        }
        return optional.get().comp_349().method_9564();
    }
}