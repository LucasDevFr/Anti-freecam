package me.antifreecam.mixin;

import me.antifreecam.AntiFreecamCommand;
import me.antifreecam.AntiFreecamMod;
import net.fabricmc.fabric.mixin.event.interaction.ServerPlayNetworkHandlerInteractEntityHandlerMixin;
import net.minecraft.class_1937;
import net.minecraft.class_2672;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_8608;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static me.antifreecam.ChunkMaskingUtil.buildMaskedPacket;

@Mixin(class_8608.class)
public class PlayerChunkSenderMixin {
    private static final ThreadLocal<Boolean> SENDING_MASKED = ThreadLocal.withInitial(() -> false);

    @Inject(method = "sendChunk", at = @At("HEAD"), cancellable = true)
    private static void onSendChunk(class_3244 connection,
                                    class_3218 level,
                                    class_2818 chunk,
                                    CallbackInfo ci) {
        if (!AntiFreecamMod.CONFIG.enabled) return;

        class_3222 player = connection.field_14140;
        if (AntiFreecamCommand.isExempt(player)) return;
        if (player.method_51469().method_27983().equals(class_1937.field_25180)) return;

        int playerY = (int) Math.floor(player.method_23318());

        // Build and send the masked packet manually
        class_2672 fakePacket = buildMaskedPacket(chunk, level, player);
        connection.method_14364(fakePacket);

        ci.cancel();
    }
}