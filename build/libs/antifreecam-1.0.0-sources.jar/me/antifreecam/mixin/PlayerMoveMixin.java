package me.antifreecam.mixin;

import me.antifreecam.AntiFreecamCommand;
import me.antifreecam.AntiFreecamMod;
import net.minecraft.class_1937;
import net.minecraft.class_2672;
import net.minecraft.class_2818;
import net.minecraft.class_2828;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.*;

import static me.antifreecam.ChunkMaskingUtil.buildMaskedPacket;

@Mixin(class_3244.class)
public class PlayerMoveMixin {
    private int lastTrackedSection = Integer.MAX_VALUE;
    private final Queue<class_2818> pendingChunkResends = new ArrayDeque<>();
    private static final int CHUNKS_PER_TICK = 5; // tune this
    private long lastResendTime = 0;
    private static final long RESEND_COOLDOWN_MS = 250;

    @Inject(method = "handleMovePlayer", at = @At("TAIL"))
    private void onPlayerMove(class_2828 packet, CallbackInfo ci) {
        if (!AntiFreecamMod.CONFIG.enabled) return;

        class_3222 player = ((class_3244)(Object)this).field_14140;
        if (AntiFreecamCommand.isExempt(player)) return;
        if (player.method_51469().method_27983().equals(class_1937.field_25180)) return;

        int effectiveY = Math.min((int) Math.floor(player.method_23318()), AntiFreecamMod.CONFIG.surfaceThreshold);
        int currentSection = Math.floorDiv(effectiveY, 16);

        long now = System.currentTimeMillis();
        if (currentSection != lastTrackedSection && now - lastResendTime > RESEND_COOLDOWN_MS) {
            lastResendTime = now;
            lastTrackedSection = currentSection;
            queueNearbyChunks(player);
        }
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void onTick(CallbackInfo ci) {
        if (pendingChunkResends.isEmpty()) return;
        if (!AntiFreecamMod.CONFIG.enabled) return;
        class_3222 player = ((class_3244)(Object)this).field_14140;
        class_3218 level = (class_3218) player.method_51469();

        int sent = 0;
        while (!pendingChunkResends.isEmpty() && sent < CHUNKS_PER_TICK) {
            class_2818 chunk = pendingChunkResends.poll();
            class_2672 pkt =
                    buildMaskedPacket(chunk, level, player);
            ((class_3244)(Object)this).method_14364(pkt);
            sent++;
        }
    }

    private void queueNearbyChunks(class_3222 player) {
        pendingChunkResends.clear(); // discard stale queue if section changed again
        class_3218 level = (class_3218) player.method_51469();
        int chunkX = (int) Math.floor(player.method_23317()) >> 4;
        int chunkZ = (int) Math.floor(player.method_23321()) >> 4;
        int viewDistance = level.method_8503().method_3760().method_14568();

        //int effectiveY = Math.min((int) Math.floor(player.getY()), AntiFreecamMod.CONFIG.surfaceThreshold);
        //boolean underground = effectiveY < AntiFreecamMod.CONFIG.surfaceThreshold;
        //int viewDistance = underground ? 4 : level.getServer().getPlayerList().getViewDistance();

        // Collect and sort by distance so nearest chunks send first
        List<class_2818> chunks = new ArrayList<>();
        for (int dx = -viewDistance; dx <= viewDistance; dx++) {
            for (int dz = -viewDistance; dz <= viewDistance; dz++) {
                class_2818 chunk = level.method_14178().method_21730(chunkX + dx, chunkZ + dz);
                if (chunk != null) chunks.add(chunk);
            }
        }

        chunks.sort(Comparator.comparingInt(c ->
                Math.abs(c.method_12004().field_9181 - chunkX) + Math.abs(c.method_12004().field_9180 - chunkZ)));

        pendingChunkResends.addAll(chunks);
    }

//    @Inject(method = "send(Lnet/minecraft/network/protocol/Packet;)V", at = @At("HEAD"), cancellable = true)
//    private void onSendPacket(Packet<?> packet, CallbackInfo ci) {
//        if (!AntiFreecamMod.CONFIG.enabled) return;
//        if (!(packet instanceof ClientboundAddEntityPacket entityPacket)) return;
//
//        ServerPlayer player = ((ServerGamePacketListenerImpl)(Object)this).player;
//        int playerY = (int) Math.floor(player.getY());
//        playerY = Math.min(playerY, AntiFreecamMod.CONFIG.surfaceThreshold);
//
//        int playerSection = Math.floorDiv(playerY - player.level().getMinY(), 16);
//        int entitySection = Math.floorDiv((int) Math.floor(entityPacket.getY()) - player.level().getMinY(), 16);
//
//        // Cancel if entity is in a section that would be masked
//        if (entitySection < playerSection - 1) {
//            ci.cancel();
//        }
//    }
}