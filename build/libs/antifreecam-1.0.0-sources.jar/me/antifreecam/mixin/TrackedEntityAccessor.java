package me.antifreecam.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_3231;
import net.minecraft.class_5629;

// Create this interface
@Mixin(targets = "net.minecraft.server.level.ChunkMap$TrackedEntity")
public interface TrackedEntityAccessor {
    @Accessor("serverEntity")
    class_3231 getServerEntity();

    @Accessor("entity")
    class_1297 getEntity();

    @Accessor("seenBy")
    Set<class_5629> getSeenBy();
}