package me.antifreecam.mixin;

import me.antifreecam.ChunkMaskingUtil;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import net.minecraft.class_3231;
import net.minecraft.class_5629;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Set;

@Mixin(targets = "net.minecraft.server.level.ChunkMap$TrackedEntity")
public abstract class TrackedEntityMixin {
    @Inject(
            method = "updatePlayer(Lnet/minecraft/server/level/ServerPlayer;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void onUpdatePlayer(class_3222 player, CallbackInfo ci) {
        TrackedEntityAccessor self = (TrackedEntityAccessor)(Object)this;
        class_1297 entity = self.getEntity();
        class_3231 serverEntity = self.getServerEntity();
        Set<class_5629> seenBy = self.getSeenBy();

        // Never interfere with a player's own entity
        if (entity == player) return;
        // Never interfere with players at all (optional, but safer)
        //if (entity instanceof ServerPlayer) return;

        if (ChunkMaskingUtil.isEntityInMaskedSection(entity, player)) {
            seenBy.remove(player.field_13987);
            serverEntity.method_14302(player);
            ci.cancel();
        } else if (!seenBy.contains(player.field_13987)) {
            // Only re-add if vanilla would normally be tracking this
            // (i.e. player is within range)
            seenBy.add(player.field_13987);
            serverEntity.method_18760(player);
            ci.cancel();
        }
    }
}